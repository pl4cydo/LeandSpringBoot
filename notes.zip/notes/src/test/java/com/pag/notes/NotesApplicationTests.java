package com.pag.notes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
