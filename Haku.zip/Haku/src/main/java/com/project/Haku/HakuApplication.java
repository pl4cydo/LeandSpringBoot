package com.project.Haku;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HakuApplication {

	public static void main(String[] args) {
		SpringApplication.run(HakuApplication.class, args);
	}

}
